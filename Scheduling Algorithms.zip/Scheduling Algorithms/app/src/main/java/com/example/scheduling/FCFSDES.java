package com.example.scheduling;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FCFSDES extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fcfsdes);
    }
}